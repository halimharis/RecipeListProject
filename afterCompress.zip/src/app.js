import main from './script/main.js';
import '@fortawesome/fontawesome-free/css/all.min.css';
import '/dist/output.css';

document.addEventListener('DOMContentLoaded', main);